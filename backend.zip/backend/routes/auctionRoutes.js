const express = require('express');
const router = express.Router();
const Auction = require('../models/auctionModel');
const User = require('../models/userModel');
const { auth, isAuctioneer, isBidder } = require('../middleware/auth');
const socketIO = require('../socket');
const mongoose = require('mongoose');

// Middleware to protect routes
const protect = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ message: 'Not authorized' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret');
    req.user = { id: decoded.id, username: decoded.username, role: decoded.role };
    next();
  } catch (error) {
    res.status(401).json({ message: 'Not authorized' });
  }
};

// Get all active auctions (Public)
router.get('/', async (req, res) => {
  try {
    const now = new Date();
    console.log('Fetching auctions at:', now); // Debug log

    const auctions = await Auction.find({
      $or: [
        // Show active auctions that haven't ended
        { 
          endTime: { $gt: now },
          status: { $ne: 'cancelled' }
        },
        // Show auctions that just ended (within last 24 hours)
        {
          endTime: { 
            $gt: new Date(now.getTime() - 24 * 60 * 60 * 1000),
            $lte: now
          },
          status: { $ne: 'cancelled' }
        }
      ]
    })
    .populate('seller', 'username profile.fullName')
    .sort({ endTime: 1 })
    .lean();

    console.log('Found auctions:', auctions.length); // Debug log
    
    res.json(auctions);
  } catch (error) {
    console.error('Error in GET /api/auctions:', error);
    res.status(500).json({ 
      message: 'Failed to fetch auctions',
      error: error.message 
    });
  }
});

// Create new auction (Auctioneer only)
router.post('/', [auth, isAuctioneer], async (req, res) => {
  try {
    const { title, description, startingPrice, imageUrl, startTime, endTime } = req.body;

    // Validate required fields
    if (!title || !description || !startingPrice || !imageUrl || !endTime) {
      return res.status(400).json({ 
        message: 'Please provide all required fields' 
      });
    }

    // Validate prices
    const price = Number(startingPrice);
    if (isNaN(price) || price <= 0) {
      return res.status(400).json({ 
        message: 'Starting price must be a positive number' 
      });
    }

    // Validate dates
    const end = new Date(endTime);
    const start = startTime ? new Date(startTime) : new Date();
    if (end <= start) {
      return res.status(400).json({ 
        message: 'End time must be after start time' 
      });
    }

    const auction = await Auction.create({
      title: title.trim(),
      description: description.trim(),
      startingPrice: price,
      currentPrice: price,
      imageUrl: imageUrl.trim(),
      seller: req.user.id,
      startTime: start,
      endTime: end,
      status: 'active'
    });

    // Populate seller information before sending response
    await auction.populate('seller', 'username profile.fullName');

    res.status(201).json(auction);
  } catch (error) {
    console.error('Error creating auction:', error);
    res.status(400).json({ 
      message: 'Failed to create auction',
      error: error.message 
    });
  }
});

// Get auction by ID
router.get('/:id', async (req, res) => {
  try {
    const auction = await Auction.findById(req.params.id)
      .populate('seller', 'username profile.fullName')
      .populate('bids.user', 'username profile.fullName')
      .lean();

    if (!auction) {
      return res.status(404).json({ message: 'Auction not found' });
    }

    res.json(auction);
  } catch (error) {
    console.error('Error fetching auction:', error);
    res.status(500).json({ 
      message: 'Failed to fetch auction',
      error: error.message 
    });
  }
});

// Get completed auctions (Authenticated users only)
router.get('/completed', auth, async (req, res) => {
  try {
    const auctions = await Auction.find({
      endTime: { $lte: new Date() },
      'bids.0': { $exists: true },
      $or: [
        { seller: req.user.id },
        { 'bids.user': req.user.id }
      ]
    })
    .populate('seller', 'username')
    .populate('bids.user', 'username')
    .sort('-endTime');

    res.json(auctions);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get my auctions (Auctioneer only)
router.get('/my-auctions', [auth, isAuctioneer], async (req, res) => {
  try {
    console.log('Fetching auctions for user:', {
      id: req.user.id,
      username: req.user.username,
      role: req.user.role
    });

    if (!mongoose.Types.ObjectId.isValid(req.user.id)) {
      console.error('Invalid user ID:', req.user.id);
      return res.status(400).json({ message: 'Invalid user ID' });
    }

    const sellerId = new mongoose.Types.ObjectId(req.user.id);
    console.log('Finding auctions with seller:', sellerId);

    const auctions = await Auction.find({ seller: sellerId })
      .populate('seller', 'username profile.fullName')
      .populate('bids.user', 'username profile.fullName')
      .sort('-createdAt')
      .lean();

    console.log('Found auctions:', auctions.length);
    
    // Convert ObjectIds to strings and handle null/undefined values
    const processedAuctions = auctions.map(auction => ({
      ...auction,
      _id: auction._id.toString(),
      seller: auction.seller ? {
        ...auction.seller,
        _id: auction.seller._id.toString()
      } : null,
      bids: (auction.bids || []).map(bid => ({
        ...bid,
        user: bid.user ? {
          ...bid.user,
          _id: bid.user._id.toString()
        } : null
      }))
    }));

    res.json(processedAuctions);
  } catch (error) {
    console.error('Error in GET /my-auctions:', error);
    res.status(500).json({ 
      message: 'Failed to fetch your auctions',
      error: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

// Get single auction
router.get('/:id', async (req, res) => {
  try {
    const auction = await Auction.findById(req.params.id)
      .populate('seller', 'username profile')
      .populate('bids.user', 'username')
      .populate('winner', 'username');
    
    if (!auction) {
      return res.status(404).json({ message: 'Auction not found' });
    }
    res.json(auction);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Place a bid (Bidder only)
router.post('/:id/bid', [auth, isBidder], async (req, res) => {
  try {
    const { amount } = req.body;
    const auctionId = req.params.id;

    // Input validation
    if (!amount || isNaN(amount)) {
      return res.status(400).json({ message: 'Please provide a valid bid amount' });
    }

    if (!mongoose.Types.ObjectId.isValid(auctionId)) {
      return res.status(400).json({ message: 'Invalid auction ID' });
    }

    // Find auction and populate seller details
    const auction = await Auction.findById(auctionId)
      .populate('seller', 'username email')
      .populate('bids.user', 'username email');

    if (!auction) {
      return res.status(404).json({ message: 'Auction not found' });
    }

    // Check if auction is active
    const now = new Date();
    if (now > new Date(auction.endTime)) {
      return res.status(400).json({ message: 'Auction has ended' });
    }

    if (auction.status !== 'active') {
      return res.status(400).json({ message: 'Auction is not active' });
    }

    // Check if seller is trying to bid on their own auction
    if (auction.seller._id.toString() === req.user.id) {
      return res.status(400).json({ message: 'You cannot bid on your own auction' });
    }

    // Get the current highest bid
    const currentHighestBid = auction.bids.length > 0 
      ? Math.max(...auction.bids.map(bid => bid.amount))
      : auction.startingPrice;

    // Validate bid amount
    if (amount <= currentHighestBid) {
      return res.status(400).json({ 
        message: `Bid must be higher than current highest bid: $${currentHighestBid}` 
      });
    }

    // Create new bid
    const newBid = {
      user: req.user.id,
      amount: amount,
      time: new Date()
    };

    // Add bid to auction
    auction.bids.push(newBid);
    auction.currentPrice = amount;
    auction.markModified('bids');

    // Save the auction
    await auction.save();

    // Populate the new bid's user information
    const populatedAuction = await Auction.findById(auctionId)
      .populate('seller', 'username email')
      .populate('bids.user', 'username email')
      .lean();

    // Get the newly added bid
    const addedBid = populatedAuction.bids[populatedAuction.bids.length - 1];

    // Prepare response data
    const bidResponse = {
      bid: {
        id: addedBid._id,
        amount: addedBid.amount,
        time: addedBid.time,
        user: {
          id: addedBid.user._id,
          username: addedBid.user.username
        }
      },
      auction: {
        id: populatedAuction._id,
        title: populatedAuction.title,
        currentPrice: populatedAuction.currentPrice,
        totalBids: populatedAuction.bids.length
      }
    };

    // Log successful bid
    console.log(`New bid placed - Auction: ${auctionId}, User: ${req.user.id}, Amount: ${amount}`);

    res.json(bidResponse);
  } catch (error) {
    console.error('Error placing bid:', error);
    res.status(500).json({ 
      message: 'Error placing bid',
      error: error.message 
    });
  }
});

// End auction
router.post('/:id/end', [auth, isAuctioneer], async (req, res) => {
  try {
    const auction = await Auction.findById(req.params.id);

    if (!auction) {
      return res.status(404).json({ message: 'Auction not found' });
    }

    // Check if user is the seller
    if (auction.seller.toString() !== req.user.id) {
      return res.status(401).json({ message: 'Not authorized' });
    }

    // Set winner as highest bidder
    if (auction.bids.length > 0) {
      const highestBid = auction.bids.reduce((prev, current) => 
        prev.amount > current.amount ? prev : current
      );
      auction.winner = highestBid.user;
    }

    auction.status = 'ended';
    auction.endTime = new Date();

    const updatedAuction = await auction.save();
    
    // Emit socket event for auction end
    const io = socketIO.getIO();
    io.to(`auction-${req.params.id}`).emit('auction ended', updatedAuction);

    res.json(updatedAuction);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete an auction (Auctioneer only)
router.delete('/:id', [auth, isAuctioneer], async (req, res) => {
  try {
    const auctionId = req.params.id;
    
    // Validate auction ID
    if (!mongoose.Types.ObjectId.isValid(auctionId)) {
      return res.status(400).json({ message: 'Invalid auction ID' });
    }

    // Find the auction
    const auction = await Auction.findById(auctionId);
    
    if (!auction) {
      return res.status(404).json({ message: 'Auction not found' });
    }

    // Check if the user is the owner of the auction
    if (auction.seller.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized to delete this auction' });
    }

    // Check if the auction has any bids
    if (auction.bids && auction.bids.length > 0) {
      return res.status(400).json({ 
        message: 'Cannot delete auction with existing bids' 
      });
    }

    // Delete the auction
    await Auction.findByIdAndDelete(auctionId);

    // Log the deletion
    console.log(`Auction ${auctionId} deleted by user ${req.user.id}`);

    res.json({ message: 'Auction deleted successfully' });
  } catch (error) {
    console.error('Error deleting auction:', error);
    res.status(500).json({ 
      message: 'Error deleting auction',
      error: error.message 
    });
  }
});

// Get bidder's active bids
router.get('/bidder/active-bids', [auth, isBidder], async (req, res) => {
  try {
    const auctions = await Auction.find({
      'bids.user': req.user.id,
      endTime: { $gt: new Date() }
    })
    .populate('seller', 'username')
    .populate('bids.user', 'username')
    .sort({ endTime: 1 });

    res.json(auctions);
  } catch (error) {
    console.error('Error fetching active bids:', error);
    res.status(500).json({ message: 'Error fetching active bids' });
  }
});

// Get bidder's won auctions
router.get('/bidder/won-auctions', [auth, isBidder], async (req, res) => {
  try {
    const auctions = await Auction.find({
      endTime: { $lt: new Date() },
      'bids.user': req.user.id,
    })
    .populate('seller', 'username')
    .populate('bids.user', 'username')
    .sort({ endTime: -1 });

    // Filter to only include auctions where the user's bid is the highest
    const wonAuctions = auctions.filter(auction => {
      const highestBid = auction.bids.reduce((prev, current) => 
        prev.amount > current.amount ? prev : current
      );
      return highestBid.user._id.toString() === req.user.id;
    });

    res.json(wonAuctions);
  } catch (error) {
    console.error('Error fetching won auctions:', error);
    res.status(500).json({ message: 'Error fetching won auctions' });
  }
});

// Get auction end details (contact information)
router.get('/:id/end-details', auth, async (req, res) => {
  try {
    const auction = await Auction.findById(req.params.id)
      .populate('seller', 'username email profile.fullName profile.phoneNumber profile.address')
      .populate('bids.user', 'username email profile.fullName profile.phoneNumber profile.address');

    if (!auction) {
      return res.status(404).json({ message: 'Auction not found' });
    }

    // Check if auction has ended
    if (new Date(auction.endTime) > new Date()) {
      return res.status(400).json({ message: 'Auction has not ended yet' });
    }

    // Get winner (highest bidder)
    const winner = auction.bids.length > 0 
      ? auction.bids.reduce((prev, current) => 
          prev.amount > current.amount ? prev : current
        ).user
      : null;

    // Check if user is authorized to view details (must be seller or winner)
    if (req.user.id !== auction.seller._id.toString() && 
        (!winner || req.user.id !== winner._id.toString())) {
      return res.status(403).json({ message: 'Not authorized to view contact details' });
    }

    const response = {
      auctionTitle: auction.title,
      finalPrice: auction.currentPrice,
      endTime: auction.endTime,
      seller: {
        username: auction.seller.username,
        fullName: auction.seller.profile.fullName,
        email: auction.seller.email,
        phoneNumber: auction.seller.profile.phoneNumber,
        address: auction.seller.profile.address
      }
    };

    if (winner) {
      response.winner = {
        username: winner.username,
        fullName: winner.profile.fullName,
        email: winner.email,
        phoneNumber: winner.profile.phoneNumber,
        address: winner.profile.address
      };
    }

    // Send notification through socket
    const io = socketIO.getIO();
    if (io) {
      // Notify seller
      io.to(`user_${auction.seller._id}`).emit('auction_ended_details', {
        auctionId: auction._id,
        winner: winner ? {
          username: winner.username,
          fullName: winner.profile.fullName,
          email: winner.email,
          phoneNumber: winner.profile.phoneNumber
        } : null,
        message: winner 
          ? `Your auction "${auction.title}" has ended. The winner is ${winner.username}. Contact details have been shared.`
          : `Your auction "${auction.title}" has ended with no bids.`
      });

      // Notify winner
      if (winner) {
        io.to(`user_${winner._id}`).emit('auction_ended_details', {
          auctionId: auction._id,
          seller: {
            username: auction.seller.username,
            fullName: auction.seller.profile.fullName,
            email: auction.seller.email,
            phoneNumber: auction.seller.profile.phoneNumber
          },
          message: `Congratulations! You won the auction "${auction.title}". Contact details have been shared.`
        });
      }
    }

    res.json(response);
  } catch (error) {
    console.error('Error getting auction end details:', error);
    res.status(500).json({ message: 'Error getting auction details' });
  }
});

// Re-auction an item
router.post('/:id/reauction', [auth, isAuctioneer], async (req, res) => {
  try {
    const { startTime, endTime, startingPrice } = req.body;
    const auction = await Auction.findById(req.params.id);

    if (!auction) {
      return res.status(404).json({ message: 'Auction not found' });
    }

    // Check if user is the seller
    if (auction.seller.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Only the seller can re-auction this item' });
    }

    // Check if auction has ended
    if (new Date(auction.endTime) > new Date()) {
      return res.status(400).json({ message: 'Cannot re-auction an active item' });
    }

    // Check if there were any bids
    if (auction.bids && auction.bids.length > 0) {
      return res.status(400).json({ message: 'Cannot re-auction an item that received bids' });
    }

    // Validate new auction times
    const newStartTime = new Date(startTime);
    const newEndTime = new Date(endTime);
    const now = new Date();

    if (newStartTime < now) {
      return res.status(400).json({ message: 'Start time must be in the future' });
    }

    if (newEndTime <= newStartTime) {
      return res.status(400).json({ message: 'End time must be after start time' });
    }

    if (parseFloat(startingPrice) <= 0) {
      return res.status(400).json({ message: 'Starting price must be greater than 0' });
    }

    // Create new auction with same details but new times
    const newAuction = await Auction.create({
      title: auction.title,
      description: auction.description,
      startingPrice: parseFloat(startingPrice),
      currentPrice: parseFloat(startingPrice),
      imageUrl: auction.imageUrl,
      seller: req.user.id,
      startTime: newStartTime,
      endTime: newEndTime,
      status: 'active',
      bids: [],
      originalAuctionId: auction._id
    });

    // Update original auction status
    auction.status = 'reposted';
    auction.repostedAuctionId = newAuction._id;
    await auction.save();

    // Notify through socket
    const io = socketIO.getIO();
    if (io) {
      io.emit('auction_reposted', {
        originalAuction: auction,
        newAuction: newAuction
      });
    }

    res.status(201).json(newAuction);
  } catch (error) {
    console.error('Error in re-auction:', error);
    res.status(500).json({ message: 'Error re-auctioning item' });
  }
});

// Get auctions for bidder dashboard
router.get('/user/bids', [auth, isBidder], async (req, res) => {
  try {
    const { status } = req.query;
    if (!status) {
      return res.status(400).json({ message: 'Status parameter is required' });
    }

    const now = new Date();
    
    // Ensure we have a valid user
    if (!req.user || !req.user._id) {
      console.error('No user found in request');
      return res.status(401).json({ message: 'User not authenticated' });
    }

    console.log('Fetching bids for user:', req.user._id, 'with status:', status);

    let query = {
      'bids.user': req.user._id
    };

    switch (status) {
      case 'active':
        query.endTime = { $gt: now };
        break;

      case 'won':
        query.endTime = { $lte: now };
        break;

      case 'lost':
        query.endTime = { $lte: now };
        break;

      default:
        return res.status(400).json({ message: 'Invalid status parameter' });
    }

    console.log('Executing query:', JSON.stringify(query));

    const auctions = await Auction.find(query)
      .populate('seller', 'username')
      .populate('bids.user', 'username')
      .sort(status === 'active' ? 'endTime' : '-endTime');

    console.log(`Found ${auctions.length} auctions before filtering`);

    let filteredAuctions = auctions;

    if (status === 'won') {
      filteredAuctions = auctions.filter(auction => {
        const lastBid = auction.bids[auction.bids.length - 1];
        return lastBid && lastBid.user._id.toString() === req.user._id.toString();
      });
    } else if (status === 'lost') {
      filteredAuctions = auctions.filter(auction => {
        const lastBid = auction.bids[auction.bids.length - 1];
        return lastBid && lastBid.user._id.toString() !== req.user._id.toString();
      });
    }

    console.log(`Returning ${filteredAuctions.length} auctions after filtering`);
    res.json(filteredAuctions);

  } catch (error) {
    console.error('Error in bidder auctions route:', error);
    res.status(500).json({ 
      message: 'Error fetching your auctions',
      error: error.message
    });
  }
});

// Delete all auctions (Admin only)
router.delete('/all', [auth, isAuctioneer], async (req, res) => {
  try {
    // For safety, check if user is an admin or has special privileges
    if (req.user.role !== 'auctioneer') {
      return res.status(403).json({ message: 'Not authorized to delete all auctions' });
    }

    // Delete all auctions
    await Auction.deleteMany({});

    res.json({ message: 'All auctions have been deleted' });
  } catch (error) {
    console.error('Error deleting all auctions:', error);
    res.status(500).json({ message: 'Error deleting auctions' });
  }
});

// Get user's won auctions and total spent
router.get('/my-won-auctions', [auth, isBidder], async (req, res) => {
  try {
    // Find all ended auctions where the user is the winner
    const wonAuctions = await Auction.find({
      winner: req.user.id,
      status: 'ended'
    }).sort({ endTime: -1 });

    // Calculate total spent
    const totalSpent = wonAuctions.reduce((total, auction) => total + auction.currentPrice, 0);

    res.json({
      wonAuctions,
      totalSpent
    });
  } catch (error) {
    console.error('Error fetching won auctions:', error);
    res.status(500).json({ message: 'Error fetching won auctions' });
  }
});

// Test auth route
router.get('/test-auth', [auth, isAuctioneer], async (req, res) => {
  try {
    console.log('Test auth request from user:', {
      id: req.user.id,
      username: req.user.username,
      role: req.user.role
    });
    
    res.json({ 
      message: 'Authentication successful',
      user: {
        id: req.user.id,
        username: req.user.username,
        role: req.user.role
      }
    });
  } catch (error) {
    console.error('Test auth error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Debug route to check all auctions
router.get('/debug/all-auctions', async (req, res) => {
  try {
    const auctions = await Auction.find()
      .populate('seller', 'username role')
      .lean();
    
    console.log('All auctions:', JSON.stringify(auctions, null, 2));
    res.json(auctions);
  } catch (error) {
    console.error('Debug route error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Debug route to check user's auctions
router.get('/debug/user-auctions/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    console.log('Checking auctions for user:', userId);
    
    // Convert userId to ObjectId
    const sellerId = new mongoose.Types.ObjectId(userId);
    const auctions = await Auction.find({ seller: sellerId })
      .populate('seller', 'username role')
      .lean();
    
    console.log('User auctions:', JSON.stringify(auctions, null, 2));
    res.json(auctions);
  } catch (error) {
    console.error('Debug route error:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;

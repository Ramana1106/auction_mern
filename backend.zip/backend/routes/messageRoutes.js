const express = require('express');
const router = express.Router();
const Message = require('../models/messageModel');
const Auction = require('../models/auctionModel');
const auth = require('../middleware/auth');
const socketIO = require('../socket');

// Send a message
router.post('/', auth, async (req, res) => {
  try {
    const { auctionId, receiverId, content } = req.body;

    // Verify auction exists and is ended
    const auction = await Auction.findById(auctionId);
    if (!auction) {
      return res.status(404).json({ message: 'Auction not found' });
    }

    // Verify user is either seller or winner
    const isSellerOrWinner = 
      auction.seller.toString() === req.user.id ||
      (auction.bids.length > 0 && 
       auction.bids.reduce((prev, current) => 
         prev.amount > current.amount ? prev : current
       ).user.toString() === req.user.id);

    if (!isSellerOrWinner) {
      return res.status(403).json({ message: 'Not authorized to send messages for this auction' });
    }

    const message = await Message.create({
      auction: auctionId,
      sender: req.user.id,
      receiver: receiverId,
      content
    });

    // Populate sender and receiver info
    await message.populate([
      { path: 'sender', select: 'username profile.fullName' },
      { path: 'receiver', select: 'username profile.fullName' }
    ]);

    // Send real-time notification
    const io = socketIO.getIO();
    if (io) {
      io.to(`user_${receiverId}`).emit('new_message', {
        message,
        auctionTitle: auction.title
      });
    }

    res.status(201).json(message);
  } catch (error) {
    console.error('Error sending message:', error);
    res.status(500).json({ message: 'Error sending message' });
  }
});

// Get conversation history for an auction
router.get('/auction/:auctionId', auth, async (req, res) => {
  try {
    const { auctionId } = req.params;
    const auction = await Auction.findById(auctionId);
    
    if (!auction) {
      return res.status(404).json({ message: 'Auction not found' });
    }

    // Verify user is either seller or winner
    const isSellerOrWinner = 
      auction.seller.toString() === req.user.id ||
      (auction.bids.length > 0 && 
       auction.bids.reduce((prev, current) => 
         prev.amount > current.amount ? prev : current
       ).user.toString() === req.user.id);

    if (!isSellerOrWinner) {
      return res.status(403).json({ message: 'Not authorized to view messages for this auction' });
    }

    // Get all messages for this auction involving the current user
    const messages = await Message.find({
      auction: auctionId,
      $or: [
        { sender: req.user.id },
        { receiver: req.user.id }
      ]
    })
    .populate('sender', 'username profile.fullName')
    .populate('receiver', 'username profile.fullName')
    .sort('createdAt');

    // Mark messages as read
    await Message.updateMany(
      {
        auction: auctionId,
        receiver: req.user.id,
        read: false
      },
      { read: true }
    );

    res.json(messages);
  } catch (error) {
    console.error('Error getting messages:', error);
    res.status(500).json({ message: 'Error getting messages' });
  }
});

// Get unread message count
router.get('/unread', auth, async (req, res) => {
  try {
    const count = await Message.countDocuments({
      receiver: req.user.id,
      read: false
    });
    res.json({ count });
  } catch (error) {
    console.error('Error getting unread count:', error);
    res.status(500).json({ message: 'Error getting unread count' });
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/userModel');

// Register User
router.post('/register', async (req, res) => {
  try {
    const { username, email, password, role, profile } = req.body;
    
    // Check for existing email
    const emailExists = await User.findOne({ email });
    if (emailExists) {
      return res.status(400).json({ 
        message: 'Email is already registered. Please use a different email address.' 
      });
    }

    // Check for existing username
    const usernameExists = await User.findOne({ username });
    if (usernameExists) {
      return res.status(400).json({ 
        message: 'Username is already taken. Please choose a different username.' 
      });
    }

    const user = await User.create({
      username,
      email,
      password,
      role: role || 'bidder', 
      profile: {
        fullName: profile?.fullName || '',
        phoneNumber: profile?.phoneNumber || '',
        address: profile?.address || '',
        company: profile?.company || '',
        businessDescription: profile?.businessDescription || '',
        verificationStatus: 'pending'
      }
    });

    const token = jwt.sign(
      { 
        id: user._id,
        username: user.username,
        role: user.role
      }, 
      process.env.JWT_SECRET || 'fallback_secret',
      { expiresIn: '30d' }
    );

    res.status(201).json({
      _id: user._id,
      username: user.username,
      email: user.email,
      role: user.role,
      profile: user.profile,
      token
    });
  } catch (error) {
    // Handle other potential MongoDB errors
    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern)[0];
      res.status(400).json({ 
        message: `This ${field} is already taken. Please choose a different ${field}.` 
      });
    } else {
      res.status(500).json({ message: error.message });
    }
  }
});

// Login User
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (user && (await user.comparePassword(password))) {
      const token = jwt.sign(
        { 
          id: user._id,
          username: user.username,
          role: user.role
        }, 
        process.env.JWT_SECRET || 'fallback_secret',
        { expiresIn: '30d' }
      );

      res.json({
        _id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
        profile: user.profile,
        token
      });
    } else {
      res.status(401).json({ message: 'Invalid email or password' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;

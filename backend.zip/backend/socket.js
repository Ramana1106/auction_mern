const socketIO = require('socket.io');

let io;

module.exports = {
  init: (server) => {
    io = socketIO(server, {
      cors: {
        origin: "http://localhost:3000",
        methods: ["GET", "POST"]
      }
    });

    io.on('connection', (socket) => {
      console.log('Client connected');

      // Join auction room
      socket.on('join auction room', (auctionId) => {
        socket.join(`auction_${auctionId}`);
        console.log(`Client joined auction room: ${auctionId}`);
      });

      // Leave auction room
      socket.on('leave auction room', (auctionId) => {
        socket.leave(`auction_${auctionId}`);
        console.log(`Client left auction room: ${auctionId}`);
      });

      // Join message room (for private messages)
      socket.on('join message room', (userId) => {
        if (userId) {
          socket.join(`user_${userId}`);
          console.log(`Client joined message room: user_${userId}`);
        }
      });

      socket.on('disconnect', () => {
        console.log('Client disconnected');
      });
    });

    return io;
  },
  getIO: () => {
    if (!io) {
      throw new Error('Socket.io not initialized!');
    }
    return io;
  }
};

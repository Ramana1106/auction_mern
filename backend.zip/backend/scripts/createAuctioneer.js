const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/userModel');

const sampleAuctioneer = {
  username: 'premium_auctioneer',
  email: 'auctioneer@example.com',
  password: 'Password123!',
  role: 'auctioneer',
  profile: {
    fullName: 'John Smith',
    phoneNumber: '+1-555-123-4567',
    address: '123 Auction Street, New York, NY 10001',
    company: 'Premium Auctions Inc.',
    businessDescription: 'Specializing in luxury items, antiques, and collectibles with over 20 years of experience.',
    verificationStatus: 'verified'
  }
};

async function createAuctioneer() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB');

    // Check if auctioneer already exists
    const existingUser = await User.findOne({ email: sampleAuctioneer.email });
    if (existingUser) {
      console.log('Auctioneer already exists');
      process.exit(0);
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(sampleAuctioneer.password, salt);

    // Create auctioneer
    const auctioneer = new User({
      ...sampleAuctioneer,
      password: hashedPassword
    });

    await auctioneer.save();
    console.log('Created sample auctioneer account:');
    console.log('Email:', sampleAuctioneer.email);
    console.log('Password:', sampleAuctioneer.password);

    await mongoose.connection.close();
    console.log('Database connection closed');
  } catch (error) {
    console.error('Error creating auctioneer:', error);
    process.exit(1);
  }
}

createAuctioneer();

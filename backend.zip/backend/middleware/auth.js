const jwt = require('jsonwebtoken');
const User = require('../models/userModel');

const auth = async (req, res, next) => {
  try {
    // Get token from header
    const authHeader = req.header('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.log('No token provided or invalid format');
      return res.status(401).json({ message: 'No token, authorization denied' });
    }

    const token = authHeader.replace('Bearer ', '');
    console.log('Token received:', token.substring(0, 20) + '...');

    try {
      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret');
      console.log('Token decoded:', {
        id: decoded.id,
        role: decoded.role,
        username: decoded.username
      });

      // Get user from database
      const user = await User.findById(decoded.id)
        .select('-password')
        .lean();

      if (!user) {
        console.log('User not found for id:', decoded.id);
        return res.status(401).json({ message: 'User not found' });
      }

      console.log('User found:', {
        id: user._id.toString(),
        role: user.role,
        username: user.username
      });

      // Add user info to request
      req.user = {
        id: user._id.toString(),
        username: user.username,
        role: user.role,
        profile: user.profile
      };

      next();
    } catch (jwtError) {
      console.error('JWT verification error:', jwtError);
      return res.status(401).json({ message: 'Token is not valid' });
    }
  } catch (error) {
    console.error('Auth middleware error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Middleware to check if user is an auctioneer
const isAuctioneer = (req, res, next) => {
  if (!req.user) {
    console.log('No user in request');
    return res.status(401).json({ message: 'Authentication required' });
  }

  console.log('Checking auctioneer role:', {
    userRole: req.user.role,
    userId: req.user.id
  });

  if (req.user.role !== 'auctioneer') {
    console.log('Access denied: not an auctioneer');
    return res.status(403).json({ message: 'Access denied. Auctioneer role required.' });
  }

  next();
};

// Middleware to check if user is a bidder
const isBidder = (req, res, next) => {
  if (!req.user) {
    console.log('No user in request');
    return res.status(401).json({ message: 'Authentication required' });
  }

  console.log('Checking bidder role:', {
    userRole: req.user.role,
    userId: req.user.id
  });

  if (req.user.role !== 'bidder') {
    console.log('Access denied: not a bidder');
    return res.status(403).json({ message: 'Access denied. Bidder role required.' });
  }

  next();
};

module.exports = { auth, isAuctioneer, isBidder };

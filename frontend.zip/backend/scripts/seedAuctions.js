const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });
const mongoose = require('mongoose');
const User = require('../models/userModel');
const Auction = require('../models/auctionModel');

const sampleAuctions = [
  {
    title: "Vintage Rolex Submariner",
    description: "A classic 1985 Rolex Submariner in excellent condition. Features include a black dial, date window, and original bracelet. Recently serviced and keeps perfect time.",
    startingPrice: 8000,
    currentPrice: 8000,
    imageUrl: "/images/auctions/rolex-submariner.jpg",
    startTime: new Date(),
    endTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
  },
  {
    title: "Rare First Edition Harry Potter Book",
    description: "First edition, first printing of Harry Potter and the Philosopher's Stone. Excellent condition with original dust jacket. A rare collector's item.",
    startingPrice: 25000,
    currentPrice: 25000,
    imageUrl: "/images/auctions/harry-potter-book.jpg",
    startTime: new Date(),
    endTime: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
  },
  {
    title: "2022 Tesla Model S Plaid",
    description: "Like-new Tesla Model S Plaid with only 5,000 miles. Midnight Silver Metallic paint, black interior, full self-driving capability. All original documentation included.",
    startingPrice: 85000,
    currentPrice: 85000,
    imageUrl: "/images/auctions/tesla-model-s.jpg",
    startTime: new Date(),
    endTime: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // 10 days from now
  },
  {
    title: "Original Andy Warhol Print",
    description: "Signed Andy Warhol screen print from the Campbell's Soup series. Includes certificate of authenticity and professional appraisal.",
    startingPrice: 45000,
    currentPrice: 45000,
    imageUrl: "/images/auctions/warhol-print.jpg",
    startTime: new Date(),
    endTime: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000), // 6 days from now
  },
  {
    title: "Antique Victorian Diamond Ring",
    description: "Stunning Victorian-era diamond ring circa 1880. Features a 2-carat old mine cut diamond in original platinum setting. Includes historical documentation.",
    startingPrice: 12000,
    currentPrice: 12000,
    imageUrl: "/images/auctions/diamond-ring.jpg",
    startTime: new Date(),
    endTime: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000), // 4 days from now
  },
  {
    title: "Signed Michael Jordan Jersey",
    description: "Authentic Chicago Bulls jersey signed by Michael Jordan. Includes certificate of authenticity from PSA/DNA. Perfect condition, never worn.",
    startingPrice: 5000,
    currentPrice: 5000,
    imageUrl: "/images/auctions/jordan-jersey.jpg",
    startTime: new Date(),
    endTime: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
  },
  {
    title: "Rare 1952 Mickey Mantle Baseball Card",
    description: "1952 Topps Mickey Mantle rookie card in PSA 7 condition. One of the most sought-after baseball cards in excellent condition.",
    startingPrice: 150000,
    currentPrice: 150000,
    imageUrl: "/images/auctions/mantle-card.jpg",
    startTime: new Date(),
    endTime: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000), // 8 days from now
  },
  {
    title: "Classic 1967 Ford Mustang GT500",
    description: "Fully restored 1967 Shelby GT500 in Highland Green. Numbers matching, documented history, show quality restoration. Only 500 original miles since restoration.",
    startingPrice: 200000,
    currentPrice: 200000,
    imageUrl: "/images/auctions/mustang-gt500.jpg",
    startTime: new Date(),
    endTime: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000), // 12 days from now
  }
];

async function seedAuctions() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB');

    // Find an auctioneer user
    const auctioneer = await User.findOne({ role: 'auctioneer' });
    if (!auctioneer) {
      console.log('No auctioneer found. Please create an auctioneer account first.');
      process.exit(1);
    }

    // Delete existing auctions
    await Auction.deleteMany({});
    console.log('Cleared existing auctions');

    // Add seller to each auction and create them
    const auctionsWithSeller = sampleAuctions.map(auction => ({
      ...auction,
      seller: auctioneer._id
    }));

    const createdAuctions = await Auction.insertMany(auctionsWithSeller);
    console.log(`Created ${createdAuctions.length} sample auctions`);

    // Close the connection
    await mongoose.connection.close();
    console.log('Database connection closed');
  } catch (error) {
    console.error('Error seeding auctions:', error);
    process.exit(1);
  }
}

// Run the seeding function
seedAuctions();

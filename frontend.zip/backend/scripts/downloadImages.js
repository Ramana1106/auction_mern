const fs = require('fs');
const path = require('path');
const https = require('https');

const imageUrls = {
  'rolex-submariner.jpg': 'https://raw.githubusercontent.com/codebase-public-resources/auction-images/main/rolex-submariner.jpg',
  'harry-potter-book.jpg': 'https://raw.githubusercontent.com/codebase-public-resources/auction-images/main/harry-potter-book.jpg',
  'tesla-model-s.jpg': 'https://raw.githubusercontent.com/codebase-public-resources/auction-images/main/tesla-model-s.jpg',
  'warhol-print.jpg': 'https://raw.githubusercontent.com/codebase-public-resources/auction-images/main/warhol-print.jpg',
  'diamond-ring.jpg': 'https://raw.githubusercontent.com/codebase-public-resources/auction-images/main/diamond-ring.jpg',
  'jordan-jersey.jpg': 'https://raw.githubusercontent.com/codebase-public-resources/auction-images/main/jordan-jersey.jpg',
  'mantle-card.jpg': 'https://raw.githubusercontent.com/codebase-public-resources/auction-images/main/mantle-card.jpg',
  'mustang-gt500.jpg': 'https://raw.githubusercontent.com/codebase-public-resources/auction-images/main/mustang-gt500.jpg'
};

const downloadImage = (url, filename) => {
  return new Promise((resolve, reject) => {
    const targetPath = path.join(__dirname, '../../frontend/public/images/auctions', filename);
    
    // Create a write stream
    const fileStream = fs.createWriteStream(targetPath);
    
    // Download the image
    https.get(url, (response) => {
      response.pipe(fileStream);
      
      fileStream.on('finish', () => {
        fileStream.close();
        console.log(`Downloaded: ${filename}`);
        resolve();
      });
    }).on('error', (err) => {
      fs.unlink(targetPath, () => {}); // Delete the file if there was an error
      reject(err);
    });
  });
};

async function downloadAllImages() {
  try {
    // Create the directory if it doesn't exist
    const dir = path.join(__dirname, '../../frontend/public/images/auctions');
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    // Download all images
    const downloads = Object.entries(imageUrls).map(([filename, url]) => {
      return downloadImage(url, filename);
    });

    await Promise.all(downloads);
    console.log('All images downloaded successfully!');
  } catch (error) {
    console.error('Error downloading images:', error);
  }
}

// Run the download
downloadAllImages();

require('dotenv').config();
const mongoose = require('mongoose');
const Auction = require('../models/auctionModel');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/auction-platform';

const deleteAllSampleAuctions = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(MONGODB_URI);
    console.log('Connected to MongoDB');

    // Delete all sample auctions that have no bids
    const result = await Auction.deleteMany({ 
      'bids.0': { $exists: false } // Only delete auctions with no bids
    });

    console.log(`Deleted ${result.deletedCount} sample auctions`);

    // Close the connection
    await mongoose.connection.close();
    console.log('Database connection closed');
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
};

// Run the deletion
deleteAllSampleAuctions();

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Container } from 'react-bootstrap';
import Navigation from './components/Navigation';
import AuctionList from './components/AuctionList';
import AuctionDetail from './components/AuctionDetail';
import CreateAuction from './components/CreateAuction';
import Login from './components/Login';
import Register from './components/Register';
import MyAuctions from './components/MyAuctions';
import MyBids from './components/MyBids';
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles/main.css';

const PrivateRoute = ({ children, allowedRoles = [] }) => {
  const user = JSON.parse(localStorage.getItem('user'));
  const token = localStorage.getItem('token');

  if (!token || !user) {
    return <Navigate to="/login" />;
  }

  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    return <Navigate to="/" />;
  }

  return children;
};

function App() {
  const user = JSON.parse(localStorage.getItem('user'));

  return (
    <Router>
      <Navigation />
      <Container>
        <Routes>
          <Route path="/" element={<AuctionList />} />
          <Route path="/auction/:id" element={<AuctionDetail />} />

          {/* Auctioneer Routes */}
          <Route
            path="/my-auctions"
            element={
              <PrivateRoute allowedRoles={['auctioneer']}>
                <MyAuctions />
              </PrivateRoute>
            }
          />
          <Route
            path="/create-auction"
            element={
              <PrivateRoute allowedRoles={['auctioneer']}>
                <CreateAuction />
              </PrivateRoute>
            }
          />

          {/* Bidder Routes */}
          <Route
            path="/my-bids"
            element={
              <PrivateRoute allowedRoles={['bidder']}>
                <MyBids />
              </PrivateRoute>
            }
          />

          {/* Auth Routes */}
          <Route 
            path="/login" 
            element={user ? <Navigate to="/" /> : <Login />} 
          />
          <Route 
            path="/register" 
            element={user ? <Navigate to="/" /> : <Register />} 
          />
        </Routes>
      </Container>
    </Router>
  );
}

export default App;

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { Card, Button, Container, Row, Col, Form, InputGroup, Alert } from 'react-bootstrap';
import config from '../config';
import '../styles/main.css';

const AuctionList = () => {
  const [auctions, setAuctions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('endTime');

  useEffect(() => {
    const fetchAuctions = async () => {
      try {
        const { data } = await axios.get(`${config.API_URL}/api/auctions`);
        console.log('Fetched auctions:', data); // Debug log
        setAuctions(data);
      } catch (error) {
        console.error('Error fetching auctions:', error);
        setError(
          error.response?.data?.message ||
          'Failed to fetch auctions. Please try again later.'
        );
      } finally {
        setLoading(false);
      }
    };

    fetchAuctions();
  }, []);

  const filteredAuctions = auctions
    .filter(auction => 
      auction.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      auction.description.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === 'price') {
        return b.currentPrice - a.currentPrice;
      } else if (sortBy === 'endTime') {
        return new Date(a.endTime) - new Date(b.endTime);
      }
      return 0;
    });

  if (loading) {
    return (
      <Container className="mt-4 text-center">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </Container>
    );
  }

  return (
    <Container className="mt-4 fade-in">
      {error && (
        <Alert variant="danger" className="mb-4" dismissible onClose={() => setError('')}>
          {error}
        </Alert>
      )}

      <Row className="mb-4">
        <Col md={6}>
          <InputGroup>
            <Form.Control
              placeholder="Search auctions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </InputGroup>
        </Col>
        <Col md={6}>
          <Form.Select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="float-md-end w-auto"
          >
            <option value="endTime">Sort by End Time</option>
            <option value="price">Sort by Price</option>
          </Form.Select>
        </Col>
      </Row>

      <Row>
        {filteredAuctions.length === 0 ? (
          <Col>
            <div className="text-center mt-4">
              <h3>No auctions found</h3>
              <p className="text-muted">
                {searchTerm 
                  ? 'Try adjusting your search terms'
                  : 'Be the first to create an auction!'}
              </p>
            </div>
          </Col>
        ) : (
          filteredAuctions.map((auction) => (
            <Col key={auction._id} sm={12} md={6} lg={4} xl={3} className="mb-4">
              <Card className="auction-card h-100">
                <div className="position-relative">
                  <Card.Img
                    variant="top"
                    src={auction.imageUrl}
                    alt={auction.title}
                    onError={(e) => {
                      e.target.src = 'https://via.placeholder.com/300x200?text=No+Image';
                    }}
                  />
                  {new Date(auction.endTime) < new Date() && (
                    <div className="position-absolute top-0 end-0 bg-danger text-white px-2 py-1 m-2 rounded">
                      Ended
                    </div>
                  )}
                </div>
                <Card.Body className="d-flex flex-column">
                  <Card.Title>{auction.title}</Card.Title>
                  <Card.Text className="text-muted">
                    {auction.description.substring(0, 100)}
                    {auction.description.length > 100 ? '...' : ''}
                  </Card.Text>
                  <div className="mt-auto">
                    <div className="d-flex justify-content-between align-items-center">
                      <span className="auction-price">${auction.currentPrice.toFixed(2)}</span>
                      <Link to={`/auction/${auction._id}`}>
                        <Button variant="primary">View Details</Button>
                      </Link>
                    </div>
                    <small className="text-muted d-block mt-2">
                      Ends: {new Date(auction.endTime).toLocaleDateString()}
                    </small>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))
        )}
      </Row>
    </Container>
  );
};

export default AuctionList;

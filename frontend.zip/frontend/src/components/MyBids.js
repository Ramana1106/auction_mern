import React, { useState, useEffect } from 'react';
import { Container, Card, Row, Col, Badge } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { formatTimeLeft } from '../utils/timeUtils';

const MyBids = () => {
  const [wonAuctions, setWonAuctions] = useState([]);
  const [totalSpent, setTotalSpent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user'));
  const token = localStorage.getItem('token');

  useEffect(() => {
    if (!user || !token) {
      navigate('/login');
      return;
    }
    fetchWonAuctions();
  }, [navigate, user, token]);

  const fetchWonAuctions = async () => {
    try {
      const config = {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      };

      const { data } = await axios.get('http://localhost:5000/api/auctions/my-won-auctions', config);
      setWonAuctions(data.wonAuctions);
      setTotalSpent(data.totalSpent);
      setLoading(false);
    } catch (error) {
      setError('Error fetching your won auctions');
      setLoading(false);
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div className="text-danger">{error}</div>;
  }

  return (
    <Container>
      <h2 className="mb-4">My Won Auctions</h2>
      <Card className="mb-4">
        <Card.Body>
          <h4>Total Amount Spent: ${(totalSpent || 0).toFixed(2)}</h4>
        </Card.Body>
      </Card>

      <Row>
        {wonAuctions.map(auction => (
          <Col key={auction._id} md={6} lg={4} className="mb-4">
            <Card>
              <Card.Img 
                variant="top" 
                src={auction.imageUrl} 
                style={{ height: '200px', objectFit: 'cover' }}
              />
              <Card.Body>
                <Card.Title>{auction.title}</Card.Title>
                <Card.Text>
                  <strong>Won Amount:</strong> ${auction.currentPrice}
                  <br />
                  <strong>End Date:</strong> {new Date(auction.endTime).toLocaleDateString()}
                  <br />
                  <Badge bg="success">Won</Badge>
                </Card.Text>
                <Card.Link 
                  href="#" 
                  onClick={() => navigate(`/auction/${auction._id}`)}
                >
                  View Details
                </Card.Link>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default MyBids;

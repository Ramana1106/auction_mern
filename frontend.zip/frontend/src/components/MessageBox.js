import React, { useState, useEffect, useRef } from 'react';
import { Card, Form, Button, Alert } from 'react-bootstrap';
import axios from 'axios';
import io from 'socket.io-client';

const MessageBox = ({ auctionId, receiverId, receiverName }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [error, setError] = useState('');
  const [socket, setSocket] = useState(null);
  const messagesEndRef = useRef(null);
  const user = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    // Connect to Socket.IO
    const newSocket = io('http://localhost:5000');
    setSocket(newSocket);

    // Join private message room
    newSocket.emit('join message room', user?._id);

    return () => {
      newSocket.close();
    };
  }, [user?._id]);

  useEffect(() => {
    if (socket) {
      socket.on('new_message', (data) => {
        if (data.message.auction === auctionId) {
          setMessages(prev => [...prev, data.message]);
          scrollToBottom();
        }
      });
    }
  }, [socket, auctionId]);

  useEffect(() => {
    fetchMessages();
  }, [auctionId]);

  const fetchMessages = async () => {
    try {
      const config = {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      };
      const { data } = await axios.get(
        `http://localhost:5000/api/messages/auction/${auctionId}`,
        config
      );
      setMessages(data);
      scrollToBottom();
    } catch (error) {
      console.error('Error fetching messages:', error);
      setError(error.response?.data?.message || 'Error fetching messages');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    try {
      const config = {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      };
      
      await axios.post(
        'http://localhost:5000/api/messages',
        {
          auctionId,
          receiverId,
          content: newMessage.trim()
        },
        config
      );

      setNewMessage('');
    } catch (error) {
      setError(error.response?.data?.message || 'Error sending message');
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const formatTime = (date) => {
    return new Date(date).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <Card className="message-box">
      <Card.Header className="d-flex justify-content-between align-items-center">
        <span>Messages with {receiverName}</span>
      </Card.Header>
      <Card.Body>
        {error && (
          <Alert variant="danger" onClose={() => setError('')} dismissible>
            {error}
          </Alert>
        )}
        
        <div className="messages-container mb-3" style={{ maxHeight: '300px', overflowY: 'auto' }}>
          {messages.map((message, index) => (
            <div
              key={index}
              className={`message ${message.sender._id === user?._id ? 'sent' : 'received'} mb-2`}
            >
              <div className="message-content">
                <div className="message-text">
                  {message.content}
                </div>
                <div className="message-time">
                  {formatTime(message.createdAt)}
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        <Form onSubmit={handleSubmit}>
          <Form.Group className="d-flex">
            <Form.Control
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type your message..."
              className="me-2"
            />
            <Button type="submit" variant="primary">
              Send
            </Button>
          </Form.Group>
        </Form>
      </Card.Body>
    </Card>
  );
};

export default MessageBox;

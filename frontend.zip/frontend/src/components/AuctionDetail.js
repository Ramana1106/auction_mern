import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Container, Row, Col, Card, Button, Form, Alert, Badge } from 'react-bootstrap';
import axios from 'axios';
import { formatTimeLeft } from '../utils/timeUtils';
import config from '../config';

const AuctionDetail = () => {
  const [auction, setAuction] = useState(null);
  const [bidAmount, setBidAmount] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [timeLeft, setTimeLeft] = useState('');
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    fetchAuction();
    const timer = setInterval(updateTimeLeft, 1000);
    return () => clearInterval(timer);
  }, [id]);

  const fetchAuction = async () => {
    try {
      setLoading(true);
      setError('');
      const token = localStorage.getItem('token');
      
      if (!token) {
        navigate('/login');
        return;
      }

      const response = await axios.get(`${config.API_URL}/api/auctions/${id}`, {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.data) {
        setAuction(response.data);
        updateTimeLeft();
      }
    } catch (error) {
      console.error('Error fetching auction:', error);
      setError(error.response?.data?.message || 'Error fetching auction details');
      
      if (error.response?.status === 401) {
        navigate('/login');
      }
    } finally {
      setLoading(false);
    }
  };

  const updateTimeLeft = () => {
    if (auction) {
      const endTime = new Date(auction.endTime);
      const now = new Date();
      if (now >= endTime) {
        setTimeLeft('Auction ended');
      } else {
        setTimeLeft(formatTimeLeft(endTime));
      }
    }
  };

  const handleBid = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      const token = localStorage.getItem('token');
      if (!token) {
        navigate('/login');
        return;
      }

      const user = JSON.parse(localStorage.getItem('user'));
      if (!user) {
        setError('Please log in to place a bid');
        navigate('/login');
        return;
      }

      if (user.role !== 'bidder') {
        setError('Only bidders can place bids');
        return;
      }

      // Validate bid amount
      const bidValue = parseFloat(bidAmount);
      if (isNaN(bidValue) || bidValue <= 0) {
        setError('Please enter a valid bid amount');
        return;
      }

      const currentPrice = auction.currentPrice || auction.startingPrice;
      if (bidValue <= currentPrice) {
        setError(`Bid must be higher than current price: $${currentPrice}`);
        return;
      }

      // Place bid
      const response = await axios.post(
        `${config.API_URL}/api/auctions/${id}/bid`,
        { amount: bidValue },
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      // Update auction with new bid
      if (response.data) {
        setSuccess('Bid placed successfully!');
        setBidAmount('');
        await fetchAuction(); // Refresh auction data
      }
    } catch (error) {
      console.error('Error placing bid:', error);
      const errorMessage = error.response?.data?.message || 'Error placing bid';
      setError(errorMessage);
      
      if (error.response?.status === 401) {
        navigate('/login');
      }
    }
  };

  if (loading) {
    return (
      <Container className="mt-4 text-center">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </Container>
    );
  }

  if (!auction) {
    return (
      <Container className="mt-4">
        <Alert variant="danger">Auction not found</Alert>
      </Container>
    );
  }

  const isEnded = new Date(auction.endTime) <= new Date();

  return (
    <Container className="mt-4">
      <Row>
        <Col md={8}>
          <Card>
            <Card.Img 
              variant="top" 
              src={auction.imageUrl} 
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = `data:image/svg+xml,${encodeURIComponent(`
                  <svg width="800" height="400" xmlns="http://www.w3.org/2000/svg">
                    <rect width="800" height="400" fill="#f8f9fa"/>
                    <text x="50%" y="50%" font-family="Arial" font-size="24" fill="#6c757d" text-anchor="middle">
                      No Image Available
                    </text>
                  </svg>
                `)}`;
              }}
              style={{ height: '400px', objectFit: 'cover' }}
            />
            <Card.Body>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <Card.Title className="h3 mb-0">{auction.title}</Card.Title>
                <Badge bg={isEnded ? 'secondary' : 'success'}>
                  {isEnded ? 'Ended' : 'Active'}
                </Badge>
              </div>
              
              <Card.Text>{auction.description}</Card.Text>
              
              <hr />
              
              <div className="d-flex justify-content-between mb-3">
                <div>
                  <strong>Current Price:</strong>
                  <h4 className="text-primary mb-0">
                    ${(auction.currentPrice || auction.startingPrice).toFixed(2)}
                  </h4>
                </div>
                <div>
                  <strong>Time Left:</strong>
                  <h4 className="text-info mb-0">{timeLeft}</h4>
                </div>
              </div>

              {error && (
                <Alert variant="danger" dismissible onClose={() => setError('')}>
                  {error}
                </Alert>
              )}
              
              {success && (
                <Alert variant="success" dismissible onClose={() => setSuccess('')}>
                  {success}
                </Alert>
              )}

              {!isEnded && (
                <Form onSubmit={handleBid}>
                  <Form.Group className="mb-3">
                    <Form.Label>Your Bid Amount ($)</Form.Label>
                    <Form.Control
                      type="number"
                      step="0.01"
                      min={(auction.currentPrice || auction.startingPrice) + 0.01}
                      value={bidAmount}
                      onChange={(e) => setBidAmount(e.target.value)}
                      placeholder="Enter your bid amount"
                      required
                    />
                  </Form.Group>
                  <Button variant="primary" type="submit" className="w-100">
                    Place Bid
                  </Button>
                </Form>
              )}
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card>
            <Card.Header>
              <h5 className="mb-0">Bid History</h5>
            </Card.Header>
            <Card.Body>
              {auction.bids && auction.bids.length > 0 ? (
                <div className="bid-history">
                  {auction.bids
                    .sort((a, b) => new Date(b.time) - new Date(a.time))
                    .map((bid, index) => (
                      <div key={index} className="bid-item mb-3">
                        <div className="d-flex justify-content-between">
                          <span>
                            <strong>{bid.user.username}</strong>
                          </span>
                          <span className="text-primary">
                            ${bid.amount.toFixed(2)}
                          </span>
                        </div>
                        <small className="text-muted">
                          {new Date(bid.time).toLocaleString()}
                        </small>
                      </div>
                    ))}
                </div>
              ) : (
                <p className="text-muted">No bids yet</p>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default AuctionDetail;

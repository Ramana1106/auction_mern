import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Container, Form, Button, Alert, Card, Row, Col } from 'react-bootstrap';
import config from '../config';
import '../styles/main.css';

const Register = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'bidder',
    profile: {
      fullName: '',
      phoneNumber: '',
      address: '',
      company: '',
      businessDescription: ''
    }
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.includes('profile.')) {
      const profileField = name.split('.')[1];
      setFormData(prev => ({
        ...prev,
        profile: {
          ...prev.profile,
          [profileField]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const validateForm = () => {
    if (!formData.username || formData.username.length < 3) {
      setError('Username must be at least 3 characters long');
      return false;
    }

    if (!formData.email || !formData.email.includes('@')) {
      setError('Please enter a valid email address');
      return false;
    }

    if (!formData.password || formData.password.length < 6) {
      setError('Password must be at least 6 characters long');
      return false;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return false;
    }

    // Additional validation for required profile fields
    if (!formData.profile.fullName) {
      setError('Full name is required');
      return false;
    }

    if (!formData.profile.phoneNumber) {
      setError('Phone number is required');
      return false;
    }

    if (!formData.profile.address) {
      setError('Address is required');
      return false;
    }

    // Additional validation for auctioneer role
    if (formData.role === 'auctioneer') {
      if (!formData.profile.company) {
        setError('Company name is required for auctioneers');
        return false;
      }
      if (!formData.profile.businessDescription) {
        setError('Business description is required for auctioneers');
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    if (!validateForm()) {
      setLoading(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    try {
      const { data } = await axios.post(
        `${config.API_URL}/api/users/register`,
        {
          username: formData.username.trim(),
          email: formData.email.trim().toLowerCase(),
          password: formData.password,
          role: formData.role,
          profile: {
            ...formData.profile,
            fullName: formData.profile.fullName.trim(),
            phoneNumber: formData.profile.phoneNumber.trim(),
            address: formData.profile.address.trim(),
            company: formData.profile.company.trim(),
            businessDescription: formData.profile.businessDescription.trim()
          }
        }
      );
      
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data));
      navigate('/');
    } catch (error) {
      console.error('Registration error:', error);
      
      if (error.response?.data?.message) {
        setError(error.response.data.message);
      } else if (!navigator.onLine) {
        setError('No internet connection. Please check your network.');
      } else {
        setError('Registration failed. Please try again.');
      }
      
      window.scrollTo({ top: 0, behavior: 'smooth' });
      setLoading(false);
    }
  };

  return (
    <Container className="mt-4 fade-in">
      <Row className="justify-content-center">
        <Col md={8}>
          <Card className="shadow-sm">
            <Card.Header className="bg-primary text-white">
              <h2 className="mb-0">Register Account</h2>
            </Card.Header>
            <Card.Body>
              {error && (
                <Alert 
                  variant="danger" 
                  className="mb-4"
                  dismissible 
                  onClose={() => setError('')}
                >
                  {error}
                </Alert>
              )}
              
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Username</Form.Label>
                      <Form.Control
                        type="text"
                        name="username"
                        value={formData.username}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Email</Form.Label>
                      <Form.Control
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Password</Form.Label>
                      <Form.Control
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Confirm Password</Form.Label>
                      <Form.Control
                        type="password"
                        name="confirmPassword"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>

                <hr className="my-4" />
                <h4 className="mb-3">Choose Account Type</h4>
                
                <Row className="mb-4">
                  <Col md={6}>
                    <Card 
                      className={`role-card ${formData.role === 'bidder' ? 'selected' : ''}`}
                      onClick={() => handleChange({ target: { name: 'role', value: 'bidder' } })}
                    >
                      <Card.Body>
                        <div className="d-flex align-items-center mb-2">
                          <Form.Check
                            type="radio"
                            name="role"
                            checked={formData.role === 'bidder'}
                            onChange={() => handleChange({ target: { name: 'role', value: 'bidder' } })}
                            label="Bidder"
                            className="h5 mb-0"
                          />
                        </div>
                        <p className="text-muted mb-0">
                          As a bidder, you can participate in auctions, place bids, track your bidding history,
                          and maintain a watchlist of interesting items.
                        </p>
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col md={6}>
                    <Card 
                      className={`role-card ${formData.role === 'auctioneer' ? 'selected' : ''}`}
                      onClick={() => handleChange({ target: { name: 'role', value: 'auctioneer' } })}
                    >
                      <Card.Body>
                        <div className="d-flex align-items-center mb-2">
                          <Form.Check
                            type="radio"
                            name="role"
                            checked={formData.role === 'auctioneer'}
                            onChange={() => handleChange({ target: { name: 'role', value: 'auctioneer' } })}
                            label="Auctioneer"
                            className="h5 mb-0"
                          />
                        </div>
                        <p className="text-muted mb-0">
                          As an auctioneer, you can create and manage auctions, track bids,
                          and build your reputation in the marketplace.
                        </p>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>

                <hr className="my-4" />
                <h4 className="mb-3">Profile Information</h4>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Full Name</Form.Label>
                      <Form.Control
                        type="text"
                        name="profile.fullName"
                        value={formData.profile.fullName}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Phone Number</Form.Label>
                      <Form.Control
                        type="tel"
                        name="profile.phoneNumber"
                        value={formData.profile.phoneNumber}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>

                <Form.Group className="mb-3">
                  <Form.Label>Address</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={2}
                    name="profile.address"
                    value={formData.profile.address}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                {formData.role === 'auctioneer' && (
                  <>
                    <Form.Group className="mb-3">
                      <Form.Label>Company Name</Form.Label>
                      <Form.Control
                        type="text"
                        name="profile.company"
                        value={formData.profile.company}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Business Description</Form.Label>
                      <Form.Control
                        as="textarea"
                        rows={3}
                        name="profile.businessDescription"
                        value={formData.profile.businessDescription}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </>
                )}

                <div className="d-grid gap-2">
                  <Button 
                    variant="primary" 
                    type="submit"
                    disabled={loading}
                  >
                    {loading ? 'Registering...' : 'Register'}
                  </Button>
                </div>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Register;

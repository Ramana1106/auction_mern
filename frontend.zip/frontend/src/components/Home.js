import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Card, Button, Badge, Nav } from 'react-bootstrap';
import axios from 'axios';
import { formatTimeLeft } from '../utils/timeUtils';
import toast from 'react-hot-toast'; // Assuming you have react-hot-toast installed

const Home = () => {
  const [auctions, setAuctions] = useState([]);
  const [view, setView] = useState('active'); // 'active' or 'completed'
  const [loading, setLoading] = useState(true);
  const user = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    fetchAuctions();
  }, [view]);

  const fetchAuctions = async () => {
    try {
      setLoading(true);
      const config = {
        headers: view === 'completed' ? { Authorization: `Bearer ${localStorage.getItem('token')}` } : {}
      };
      
      const endpoint = view === 'completed' ? '/api/auctions/completed' : '/api/auctions';
      const { data } = await axios.get(`http://localhost:5000${endpoint}`, config);
      setAuctions(data);
    } catch (error) {
      console.error('Error fetching auctions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAllAuctions = async () => {
    if (!window.confirm('Are you sure you want to delete ALL auctions? This cannot be undone!')) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const config = {
        headers: { Authorization: `Bearer ${token}` }
      };

      await axios.delete('http://localhost:5000/api/auctions/all', config);
      fetchAuctions(); // Refresh the auction list
      toast.success('All auctions have been deleted');
    } catch (error) {
      console.error('Error deleting auctions:', error);
      toast.error(error.response?.data?.message || 'Error deleting auctions');
    }
  };

  return (
    <Container>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1>Auctions</h1>
        {user && (
          <Nav variant="tabs">
            <Nav.Item>
              <Nav.Link 
                active={view === 'active'} 
                onClick={() => setView('active')}
              >
                Active Auctions
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link 
                active={view === 'completed'} 
                onClick={() => setView('completed')}
              >
                Completed Auctions
              </Nav.Link>
            </Nav.Item>
          </Nav>
        )}
        {user?.role === 'auctioneer' && (
          <>
            <Button 
              variant="danger" 
              onClick={handleDeleteAllAuctions}
              className="me-2"
            >
              Delete All Auctions
            </Button>
            <Link to="/create-auction" className="btn btn-primary">
              Create New Auction
            </Link>
          </>
        )}
      </div>

      {loading ? (
        <div className="text-center">Loading...</div>
      ) : auctions.length === 0 ? (
        <div className="text-center">
          <p>No {view} auctions found.</p>
          {view === 'active' && (
            <p>Check back later for new auctions or create your own!</p>
          )}
        </div>
      ) : (
        <Row xs={1} md={2} lg={3} className="g-4">
          {auctions.map(auction => (
            <Col key={auction._id}>
              <Card className="h-100 auction-card">
                <div className="position-relative">
                  <Card.Img 
                    variant="top" 
                    src={auction.imageUrl} 
                    style={{ height: '200px', objectFit: 'cover' }}
                  />
                  {view === 'active' && (
                    <div className="timer-overlay">
                      <Badge 
                        bg={auction.endTime > new Date().toISOString() ? "primary" : "secondary"}
                        className="timer-badge"
                      >
                        {formatTimeLeft(auction.endTime)}
                      </Badge>
                    </div>
                  )}
                </div>
                <Card.Body>
                  <Card.Title>{auction.title}</Card.Title>
                  <Card.Text>
                    Current Price: ${auction.currentPrice}
                    <br />
                    Seller: {auction.seller.username}
                    {view === 'completed' && (
                      <>
                        <br />
                        Status: {auction.bids.length > 0 ? 'Sold' : 'Ended without bids'}
                        {auction.bids.length > 0 && (
                          <>
                            <br />
                            Winner: {auction.bids[auction.bids.length - 1].user.username}
                          </>
                        )}
                      </>
                    )}
                  </Card.Text>
                  <Link 
                    to={`/auction/${auction._id}`} 
                    className="btn btn-primary"
                  >
                    View Details
                  </Link>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </Container>
  );
};

export default Home;

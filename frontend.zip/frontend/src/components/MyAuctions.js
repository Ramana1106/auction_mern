import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Badge, Button, Alert } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { formatTimeLeft } from '../utils/timeUtils';
import config from '../config';

const MyAuctions = () => {
  const [auctions, setAuctions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const user = JSON.parse(localStorage.getItem('user'));
        const token = localStorage.getItem('token');

        if (!user || !token) {
          console.log('No user or token found, redirecting to login');
          navigate('/login');
          return;
        }

        if (user.role !== 'auctioneer') {
          console.log('User is not an auctioneer, redirecting to home');
          navigate('/');
          return;
        }

        await fetchMyAuctions(token);
      } catch (error) {
        console.error('Auth check error:', error);
        navigate('/login');
      }
    };

    checkAuth();
  }, [navigate]);

  const fetchMyAuctions = async (token) => {
    try {
      setLoading(true);
      setError('');
      
      console.log('Fetching auctions with token:', token.substring(0, 20) + '...');
      const response = await axios.get(`${config.API_URL}/api/auctions/my-auctions`, {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      console.log('Response:', response);
      if (response.data) {
        console.log('Fetched auctions:', response.data);
        setAuctions(Array.isArray(response.data) ? response.data : []);
      } else {
        console.error('No data in response');
        setError('No data received from server');
      }
    } catch (error) {
      console.error('Error fetching auctions:', error.response || error);
      const errorMessage = error.response?.data?.message || 'Failed to fetch your auctions';
      setError(errorMessage);
      
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        navigate('/login');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (auctionId) => {
    if (!window.confirm('Are you sure you want to delete this auction? This action cannot be undone.')) {
      return;
    }

    try {
      setError('');
      const token = localStorage.getItem('token');
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await axios.delete(`${config.API_URL}/api/auctions/${auctionId}`, {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      console.log('Delete response:', response.data);
      setSuccess(response.data.message || 'Auction deleted successfully');
      
      // Remove the deleted auction from the state
      setAuctions(prevAuctions => prevAuctions.filter(auction => auction._id !== auctionId));
    } catch (error) {
      console.error('Error deleting auction:', error.response || error);
      const errorMessage = error.response?.data?.message || 'Error deleting auction';
      setError(errorMessage);
      
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        navigate('/login');
      }
    }
  };

  const getDefaultImage = () => {
    return `data:image/svg+xml,${encodeURIComponent(`
      <svg width="300" height="200" xmlns="http://www.w3.org/2000/svg">
        <rect width="300" height="200" fill="#f8f9fa"/>
        <text x="50%" y="50%" font-family="Arial" font-size="16" fill="#6c757d" text-anchor="middle">
          No Image Available
        </text>
      </svg>
    `)}`;
  };

  if (loading) {
    return (
      <Container className="mt-4 text-center">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </Container>
    );
  }

  return (
    <Container className="mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>My Auctions</h2>
        <Button 
          variant="primary" 
          onClick={() => navigate('/create-auction')}
        >
          Create New Auction
        </Button>
      </div>
      
      {error && (
        <Alert variant="danger" dismissible onClose={() => setError('')}>
          {error}
        </Alert>
      )}
      
      {success && (
        <Alert variant="success" dismissible onClose={() => setSuccess('')}>
          {success}
        </Alert>
      )}

      <Row>
        {auctions.length === 0 ? (
          <Col>
            <Card className="text-center p-5">
              <Card.Body>
                <h3>No Auctions Found</h3>
                <p className="text-muted">
                  You haven't created any auctions yet.
                </p>
                <Button 
                  variant="primary" 
                  onClick={() => navigate('/create-auction')}
                >
                  Create Your First Auction
                </Button>
              </Card.Body>
            </Card>
          </Col>
        ) : (
          auctions.map(auction => (
            <Col key={auction._id} md={6} lg={4} className="mb-4">
              <Card className="h-100">
                <Card.Img 
                  variant="top" 
                  src={auction.imageUrl || getDefaultImage()} 
                  style={{ height: '200px', objectFit: 'cover' }}
                  onError={(e) => {
                    e.target.src = getDefaultImage();
                  }}
                />
                <Card.Body className="d-flex flex-column">
                  <Card.Title>{auction.title}</Card.Title>
                  <Card.Text className="text-muted">
                    {auction.description.substring(0, 100)}
                    {auction.description.length > 100 ? '...' : ''}
                  </Card.Text>
                  <div className="mt-auto">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <span>Current Price:</span>
                      <strong className="text-primary">
                        ${auction.currentPrice?.toFixed(2) || auction.startingPrice?.toFixed(2)}
                      </strong>
                    </div>
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <span>Total Bids:</span>
                      <Badge bg="info">{auction.bids?.length || 0}</Badge>
                    </div>
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <span>Status:</span>
                      <Badge bg={new Date(auction.endTime) < new Date() ? 'secondary' : 'success'}>
                        {new Date(auction.endTime) < new Date() ? 'Ended' : 'Active'}
                      </Badge>
                    </div>
                    <small className="text-muted d-block mb-2">
                      Time Remaining: {formatTimeLeft(auction.endTime)}
                    </small>
                    <div className="d-flex justify-content-between">
                      <Button 
                        variant="primary" 
                        size="sm"
                        onClick={() => navigate(`/auction/${auction._id}`)}
                      >
                        View Details
                      </Button>
                      <Button 
                        variant="danger" 
                        size="sm"
                        onClick={() => handleDelete(auction._id)}
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))
        )}
      </Row>
    </Container>
  );
};

export default MyAuctions;

import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Navbar, Nav, Container, Button, NavDropdown, Badge } from 'react-bootstrap';
import '../styles/main.css';

const Navigation = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user') || 'null');

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <Navbar bg="dark" variant="dark" expand="lg" className="mb-4">
      <Container>
        <Navbar.Brand as={Link} to="/">
          Online Auction
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/">Browse Auctions</Nav.Link>
            
            {user && (
              <>
                {user.role === 'auctioneer' && (
                  <>
                    <Nav.Link as={Link} to="/create-auction">Create Auction</Nav.Link>
                    <Nav.Link as={Link} to="/my-auctions">My Auctions</Nav.Link>
                  </>
                )}
                {user.role === 'bidder' && (
                  <>
                    <Nav.Link as={Link} to="/my-bids">My Bids</Nav.Link>
                  </>
                )}
              </>
            )}
          </Nav>
          
          <Nav>
            {user ? (
              <>
                <NavDropdown 
                  title={
                    <span>
                      Welcome, {user.username}
                      <Badge 
                        bg={user.role === 'auctioneer' ? 'warning' : 'info'}
                        className="ms-2"
                      >
                        {user.role}
                      </Badge>
                    </span>
                  } 
                  id="user-dropdown"
                >
                  {user.role === 'auctioneer' && (
                    <NavDropdown.Item as={Link} to="/my-auctions">
                      My Auctions
                    </NavDropdown.Item>
                  )}
                  <NavDropdown.Divider />
                  <NavDropdown.Item onClick={handleLogout}>
                    Logout
                  </NavDropdown.Item>
                </NavDropdown>
              </>
            ) : (
              <>
                <Nav.Link as={Link} to="/login">Login</Nav.Link>
                <Nav.Link as={Link} to="/register">Register</Nav.Link>
              </>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Navigation;

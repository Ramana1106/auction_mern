import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Container, Form, Button, Alert, Card, Row, Col } from 'react-bootstrap';
import config from '../config';
import '../styles/main.css';

const CreateAuction = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    startingPrice: '',
    imageUrl: '',
    endTime: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [previewImage, setPreviewImage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    if (name === 'imageUrl' && value) {
      setPreviewImage(value);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError();
    
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        setError('Please login to create an auction');
        setLoading(false);
        return;
      }

      // Validate end time
      const endTime = new Date(formData.endTime);
      const now = new Date();
      if (endTime <= now) {
        setError('End time must be in the future');
        setLoading(false);
        return;
      }

      // Convert price to number and validate
      const startingPrice = Number(formData.startingPrice);
      if (isNaN(startingPrice) || startingPrice <= 0) {
        setError('Please enter a valid starting price');
        setLoading(false);
        return;
      }

      await axios.post(
        `${config.API_URL}/api/auctions`,
        {
          ...formData,
          startingPrice,
          startTime: new Date().toISOString(),
          endTime: endTime.toISOString()
        },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      navigate('/');
    } catch (error) {
      console.error('Auction creation error:', error);
      if (error.response?.data?.message) {
        setError(error.response.data.message);
      } else if (error.response?.status === 401) {
        setError('Your session has expired. Please login again.');
      } else if (!navigator.onLine) {
        setError('No internet connection. Please check your network.');
      } else {
        setError('Failed to create auction. Please try again.');
      }
      setLoading(false);
    }
  };

  const minEndTime = () => {
    const now = new Date();
    now.setMinutes(now.getMinutes() + 10); // Minimum 10 minutes from now
    return now.toISOString().slice(0, 16);
  };

  return (
    <Container className="mt-4 fade-in">
      <Row className="justify-content-center">
        <Col md={8}>
          <Card className="shadow-sm">
            <Card.Header className="bg-primary text-white">
              <h2 className="mb-0">Create New Auction</h2>
            </Card.Header>
            <Card.Body>
              {error && <Alert variant="danger">{error}</Alert>}
              
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col md={previewImage ? 8 : 12}>
                    <Form.Group className="mb-3">
                      <Form.Label>Title</Form.Label>
                      <Form.Control
                        type="text"
                        name="title"
                        value={formData.title}
                        onChange={handleChange}
                        placeholder="Enter auction title"
                        required
                      />
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Description</Form.Label>
                      <Form.Control
                        as="textarea"
                        rows={4}
                        name="description"
                        value={formData.description}
                        onChange={handleChange}
                        placeholder="Describe your item"
                        required
                      />
                    </Form.Group>

                    <Row>
                      <Col md={6}>
                        <Form.Group className="mb-3">
                          <Form.Label>Starting Price ($)</Form.Label>
                          <Form.Control
                            type="number"
                            name="startingPrice"
                            value={formData.startingPrice}
                            onChange={handleChange}
                            min="0"
                            step="0.01"
                            placeholder="0.00"
                            required
                          />
                        </Form.Group>
                      </Col>
                      <Col md={6}>
                        <Form.Group className="mb-3">
                          <Form.Label>End Time</Form.Label>
                          <Form.Control
                            type="datetime-local"
                            name="endTime"
                            value={formData.endTime}
                            onChange={handleChange}
                            min={minEndTime()}
                            required
                          />
                        </Form.Group>
                      </Col>
                    </Row>

                    <Form.Group className="mb-3">
                      <Form.Label>Image URL</Form.Label>
                      <Form.Control
                        type="url"
                        name="imageUrl"
                        value={formData.imageUrl}
                        onChange={handleChange}
                        placeholder="Enter image URL"
                        required
                      />
                    </Form.Group>
                  </Col>

                  {previewImage && (
                    <Col md={4}>
                      <div className="position-sticky" style={{ top: '1rem' }}>
                        <p className="mb-2">Image Preview:</p>
                        <img
                          src={previewImage}
                          alt="Preview"
                          className="img-fluid rounded"
                          onError={() => setPreviewImage('')}
                        />
                      </div>
                    </Col>
                  )}
                </Row>

                <div className="d-grid gap-2">
                  <Button 
                    variant="primary" 
                    type="submit"
                    disabled={loading}
                    className="mt-3"
                  >
                    {loading ? 'Creating...' : 'Create Auction'}
                  </Button>
                </div>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default CreateAuction;

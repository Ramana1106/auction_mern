const config = {
  API_URL: 'http://localhost:5001',
  SOCKET_URL: 'http://localhost:5001'
};

export default config;

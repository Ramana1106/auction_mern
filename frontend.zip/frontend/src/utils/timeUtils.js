export const formatTimeLeft = (endTime) => {
  const end = new Date(endTime);
  const now = new Date();
  const diff = end - now;

  if (diff <= 0) return 'Ended';

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);

  let timeString = '';
  if (days > 0) timeString += `${days}d `;
  if (hours > 0) timeString += `${hours}h `;
  if (minutes > 0) timeString += `${minutes}m `;
  if (days === 0 && hours === 0) timeString += `${seconds}s`;

  return timeString.trim();
};

export const isAuctionEnded = (endTime) => {
  return new Date(endTime) <= new Date();
};

export const isAuctionUrgent = (endTime) => {
  const end = new Date(endTime);
  const now = new Date();
  const diff = end - now;
  
  // Return true if less than 10 minutes remaining
  return diff > 0 && diff <= 600000;
};
